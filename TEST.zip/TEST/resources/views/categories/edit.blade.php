<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="/categories/{{ $categorie->id }}">
    @method('PUT')
    @csrf

    Catégorie:
    
    <div>
        <label for="Nom_categorie">Nom : </label>
        <input type="text" id="Nom_categorie" name="Nom_categorie" value="{{ $categorie->id }}">
    
        <label for="image" class="col-md-4 col-form-label text-md-right">Image catégorie</label>
        <div class="col-md-6">
            <input id="image" type="file" class="form-control" name="image">
        </div>
    </div>

    
    <button>Update</button><br>
    </form>
    
    <form action="/categories/{{ $categorie->id }}" method="POST">
        @csrf
        @method('DELETE')
        <button>Delete</button><br>
    </form>
</body>
</html>