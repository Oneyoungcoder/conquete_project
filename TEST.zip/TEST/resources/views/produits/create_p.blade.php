<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="/produits">
     @csrf

    <div>
        <label for="Nom">Nom : </label>
        <input type="text" id="Nom" name="Nom"><br>

        <label for="Catégorie">Catégorie : </label>
        <select>
            @foreach ($c as $categorie)
                <option value="{{ $categorie->Nom_categorie }}">{{ $categorie->Nom_categorie }}</option>
            @endforeach
        </select>
        <br>
        <label for="Description">Description : </label>
        <input type="text" id="Description" name="Description"><br>

        <label for="Prix">Prix : </label>
        <input type="number" min="1" id="Prix" name="Prix"><br> FCFA

        <form action="/produits" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <label for="Photo">Photo : </label>
                
                <div class="col-md-6">
                    <input type="file" name="image" class="form-control">
                </div>
{{--      
                <div class="col-md-6">
                    <button type="submit" class="btn btn-success">Upload</button>
                </div> --}}
     
            </div>
        </form>
    
        {{-- <input type="file" id="Photo" name="Photo"><br> --}}
        
    </div>
    
    <button class="blue">Update</button>
    </form>
</body>
</html>