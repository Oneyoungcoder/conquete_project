<?php

namespace App\Http\Controllers;

use App\Models\Categorie;
use Illuminate\Http\Request;

class CategorieController extends Controller
{
    public function index()
    {
        $categories= Categorie::all();
        return view('categories.index', ['categories' => $categories]);
    }

    public function edit(Categorie $categorie)
    {
        return view('categories.edit', ['categorie' => $categorie]);
    }

    public function update(Categorie $categorie)
    {   
        request()->validate([
            'Nom_categorie' =>'required',
        ]);

        $categorie->update([
            'Nom_categorie' => request('Nom_categorie'),
        ]);
        
        return redirect('/categories')
            ->with('success','Product updated successfully');
    }
    
    public function imageUploadPost(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
    
        $imageName = time().'.'.$request->image->extension();  
     
        $request->image->move(public_path('images'), $imageName);
  
        /* Store $imageName name in DATABASE from HERE */
    
        return back()
            ->with('image',$imageName); 
    }
    /*
        public function update(Request $request, Product $product)
    {
        $request->validate([
            'name' => 'required',
            'detail' => 'required',
        ]);
  
        $product->update($request->all());
  
        return redirect()->route('products.index')
                        ->with('success','Product updated successfully');
    }
  */

    public function store()
    {  
        request()->validate([
            'Nom_categorie' =>'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        
        $imageName = time().'.'.request()->image->extension();  
        request()->image->move(public_path('images'), $imageName);
        Categorie::create([
            'Nom_categorie' => request('Nom_categorie'),
            'image' => $imageName,

        ]);

     
        // dd( $imageName);

        //$categorie->image = $imageName;
        return redirect('/categories');
        return back();
        
            //->with('image',$imageName); 
    }
    public function create(Categorie $categorie)
    {
        return view('categories.create');  
        $imageName = time().'.'.request()->image->extension();  
     
        request()->image->move(public_path('images'), $imageName);
    }

    public function destroy(Categorie $categorie)
    {
        $categorie->delete();
  
        return redirect('/categories')
                        ->with('success','categorie deleted successfully');
    }
}
