<?php

namespace App\Http\Controllers;

use App\Models\Produit;
use App\Models\Categorie;

use Illuminate\Http\Request;

class ProduitController extends Controller
{
    public function index_p()
    {
        $produits = Produit::all();
        return view('produits.index_p', ['produits' => $produits]);
    }

    public function edit_p(Produit $produit)
    {
        return view('produits.edit_p', ['produit' => $produit]);
    }

    public function update_p(Produit $produit)
    {   
        request()->validate([
            'Nom' =>'required',
            'Categorie' => 'required',
            'Description' =>'required',
            'Prix' =>'required',
            'Photo' =>'required',
        ]);
        $produit->update([
            'Nom' => request('Nom'),
            'Categorie' => request('Categorie'),         
            'Description' => request('Description'),
            'Prix' => request('Prix'),
            'Photo' => request('Photo')
        ]);
        return redirect('/produits');
    }

    public function store_p()
    {  
        request()->validate([
            'Nom' =>'required',
            'Description' =>'required',
            'Categorie' => 'required',
            'Prix' =>'required',
            'Photo' =>'required',
        ]);
        
        Produit::create([
            'Nom' => request('Nom'),
            'Description' => request('Description'),
            'Categorie' => request('Categorie'),
            'Prix' => request('Prix'),
            'Photo' => request('Photo')
        ]);
        return redirect('/produits');
    }

    public function create_p()
    {
        $c = Categorie::all();
        return view('produits.create_p', compact('c'));  
    }
    
}
