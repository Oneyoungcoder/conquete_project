<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="/categories" enctype="multipart/form-data">
     <?php echo csrf_field(); ?>

    <div>
        <div>
            <label for="Nom_categorie">Nom : </label>
            <input type="text" id="Nom_categorie" name="Nom_categorie"><br>
            
        </div>
        
        <div class="form-group row">
            <label for="image" class="col-md-4 col-form-label text-md-right">Image catégorie</label>
            <div class="col-md-6">
                <input id="image" type="file" class="form-control" name="image">
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Update Catégorie</button>

    </div>

    </form>

</body>
</html><?php /**PATH /home/jehovany/Downloads/TEST1/TEST/resources/views/categories/create.blade.php ENDPATH**/ ?>