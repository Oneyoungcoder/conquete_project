<html lang="en">

<head>
    <style>
        th,
        td,
        table {
            border: 1px solid black;
            /* border:1px solid black; */
            border-collapse: collapse;
        }
    </style>
    
    <title>Document</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
        <script src = "https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src = "https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
        <script>
            $(document).ready(function() {
                $('#example').DataTable();
            } );
        </script>
</head>

<body>
    <table id="example" class="display" style="width:50%">
        <caption>Catégorie</caption>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><a href="/categories/<?php echo e($categorie->id); ?>/edit"> <?php echo e($categorie -> Nom_categorie); ?></a></th>
                <?php
                    $path = url("/images/{$categorie->image}");
                ?>
                <th>   <img src="<?php echo e($path); ?>"> </th>
            </tr>
            
      
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>

    <a href="/categories/create">Add</a>
</body>

</html><?php /**PATH /home/jehovany/Downloads/TEST1/TEST/resources/views/categories/index.blade.php ENDPATH**/ ?>