<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="/categories/<?php echo e($categorie->id); ?>">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>

    Catégorie:
    
    <div>
        <label for="Nom_categorie">Nom : </label>
        <input type="text" id="Nom_categorie" name="Nom_categorie" value="<?php echo e($categorie->Nom_categorie); ?>">
    </div>

    
    <button>Update</button><br>
    </form>
    
    <form action="/categories/<?php echo e($categorie->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button>Delete</button><br>
    </form>
</body>
</html><?php /**PATH /home/jehovany/Downloads/TEST1/TEST/resources/views/categories/edit.blade.php ENDPATH**/ ?>