<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="/produits">
     <?php echo csrf_field(); ?>

    <div>
        <label for="Nom">Nom : </label>
        <input type="text" id="Nom" name="Nom"><br>

        <label for="Catégorie">Catégorie : </label>
        <input type="text" id="Catégorie" name="Catégorie"><br>
        
        <label for="Description">Description : </label>
        <input type="text" id="Description" name="Description"><br>

        <label for="Prix">Prix : </label>
        <input type="text" id="Prix" name="Prix"><br>

        <label for="Photo">Photo : </label>
        <input type="text" id="Photo" name="Photo"><br>
        
    </div>
    
    <button class="blue">Update</button>
    </form>
</body>
</html><?php /**PATH /home/Cocou/HTML/SBIN/Laravel/TEST/resources/views/produits/create_p.blade.php ENDPATH**/ ?>