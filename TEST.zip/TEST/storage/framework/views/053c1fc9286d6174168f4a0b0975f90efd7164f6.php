<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="/produits">
     <?php echo csrf_field(); ?>

    <div>
        <label for="Nom">Nom : </label>
        <input type="text" id="Nom" name="Nom"><br>

        <label for="Catégorie">Catégorie : </label>
        <select>
            <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categorie->Nom_categorie); ?>"><?php echo e($categorie->Nom_categorie); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <label for="Description">Description : </label>
        <input type="text" id="Description" name="Description"><br>

        <label for="Prix">Prix : </label>
        <input type="number" min="1" id="Prix" name="Prix"><br> FCFA

        <form action="/produits" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <label for="Photo">Photo : </label>
                
                <div class="col-md-6">
                    <input type="file" name="image" class="form-control">
                </div>

     
            </div>
        </form>
    
        
        
    </div>
    
    <button class="blue">Update</button>
    </form>
</body>
</html><?php /**PATH /home/jehovany/Downloads/TEST1/TEST/resources/views/produits/create_p.blade.php ENDPATH**/ ?>