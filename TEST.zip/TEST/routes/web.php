<?php


use App\Http\Controllers\ProduitController;
use App\Http\Controllers\CategorieController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
/*-------------------------------Post----------------------*/
Route::get('/produits', [ProduitController::class, 'index_p']);
Route::get('/categories', [CategorieController::class, 'index']);

/*-------------------------------Post----------------------*/

/*-----------------Ouvre un forme où on peut update----------------------*/
Route::get('/produits/{produit}/edit_p', [ProduitController::class, 'edit_p']);
Route::get('/categories/{categorie}/edit', [CategorieController::class, 'edit']);


/*-----------------Ouvre un forme où on peut update----------------------*/

/*------------------------UPDATE-----------------------------------*/

/*----------------------------update-------------------------------*/

/*---------------------Nouveau message----------------------------*/
Route::get('/produits/create_p', [ProduitController::class, 'create_p']);
Route::get('/categories/create', [CategorieController::class, 'create']);


Route::put('/produits/{produit}', [ProduitController::class, 'update_p']);
Route::put('/categories/{categorie}', [CategorieController::class, 'update']);

Route::post('/produits', [ProduitController::class, 'store_p']);
Route::post('/categories', [CategorieController::class, 'store']);

/*---------------------Nouveau message----------------------------*/
Route::delete('/produits/{produit}', [ProduitController::class, 'destroy_p']);
Route::delete('/categories/{categorie}', [CategorieController::class, 'destroy']);
