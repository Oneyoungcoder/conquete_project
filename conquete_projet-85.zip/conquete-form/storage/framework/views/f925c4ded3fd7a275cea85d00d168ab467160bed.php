<html lang="en">

<head>
    <style>
        th,
        td,
        table {
            border: 1px solid black;
            border-collapse: collapse;
        }
        .btn-box {
            width: 100%;
            margin: 30px auto;
            text-align: center;
        }

        button {
        width: 110px;
        height: 35px;
        margin: 0 10px;
        background: linear-gradient(to right, #ff105f, #ffad06);
        border-radius: 30px;
        border: 0;
        outline: none;
        color: #fff;
        cursor: pointer;
        }
    </style>
    
    <title>Document</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
        <script src = "https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src = "https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
        <script>
            $(document).ready(function() {
                $('#example').DataTable();
            } );
        </script>
        <script>
            $(document).ready(function() {
                $('#example1').DataTable();
            } );
        </script>
        <script>
            $(document).ready(function() {
                $('#example2').DataTable();
            } );
        </script>
</head>
<body>
    <table id="example" class="display" style="width:100%">
        <caption>Client physique</caption>
        <thead>
            <tr>
                <th>Nom et Prénom / Raison_sociale</th>
                <th>Téléphone</a></th>
                <th>Offre</th>
                <th>Forfait</th>
                <th>Adresse(Ville)</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $big): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><a href="<?php echo e(route('BigController.edit', $big->id)); ?>"><?php echo e($big->Name); ?></th>
                <th><?php echo e($big->Telephone); ?></th>
                <th><?php echo e($big->Offre); ?></th>
                <th><?php echo e($big->Forfait); ?></th>
                <th><?php echo e($big->Adresse); ?></th>
                <th><?php echo e($big->created_at); ?></th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <table id="example1" class="display1" style="width:50%">
        <caption>Personne physique</caption>
        <thead>
            <tr>
            <th>Nom</th>
            <th>Prénom</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $big1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><a href="<?php echo e(route('BigController.edit', $big->id)); ?>"><?php echo e($big1->Nom); ?></th>
                <th><?php echo e($big1->Prenom); ?></th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><br>

    <table id="example2" class="display2" style="width:50%">
        <caption>Personne moral</caption>
        <thead>
            <tr>
                <th>Raison_Social</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $big2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><a href="<?php echo e(route('BigController.edit', $big->id)); ?>"><?php echo e($big2->Raison_sociale); ?></th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    
    

    <div class="btn-box">
        <button type="button"><a href="<?php echo e(route('BigController.create')); ?>">Create</a></button> </br>
    </div>
</body>
</html><?php /**PATH /home/Cocou/HTML/SBIN/Make_form/conquete_project/post/resources/views/index.blade.php ENDPATH**/ ?>