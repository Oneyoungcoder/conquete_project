<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
    </head>
    <body class="antialiased">
    <div class="im">
        <img src="/home/Cocou/HTML/SBIN/Make_form/post/public/Start_Page.jpg" alt="Image">
    </div>
    </body>
</html>
